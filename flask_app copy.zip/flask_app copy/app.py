# Import required libraries for web framework, security, database, and utilities
from flask import Flask, request, render_template, redirect, url_for, flash, session  # Import Flask web framework components
from werkzeug.security import generate_password_hash, check_password_hash  # Import password hashing utilities
import sqlite3  # Import SQLite database library
from datetime import datetime, date, timedelta  # Import date/time utilities
import os  # Import operating system utilities
import logging  # Import logging functionality
import calendar  # Import calendar utilities

# Configure logging to help with debugging
logging.basicConfig(level=logging.DEBUG)  # Set logging level to DEBUG
logger = logging.getLogger(__name__)  # Create a logger instance for this file

# Initialize Flask application
app = Flask(__name__)  # Create Flask application instance
app.secret_key = os.urandom(24)  # Generate random secret key for session security

# Define database path as a constant
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'todo.db')  # Set path to SQLite database file

def add_user_to_db(username, password):
    """Adds a new user to the database"""
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        
        # Check if username already exists
        cursor.execute("SELECT username FROM users WHERE username = ?", (username,))  # Query to check existing username
        if cursor.fetchone():  # If username exists
            conn.close()  # Close database connection
            return False  # Return False indicating failure
        
        # Hash the password and create new user
        hashed_password = generate_password_hash(password)  # Hash the password for security
        cursor.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",  # SQL to insert new user
            (username, hashed_password)  # Values to insert
        )
        conn.commit()  # Save changes to database
        conn.close()  # Close connection
        return True  # Return True indicating success
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")  # Log any database errors
        return False  # Return False on error

# Database initialization function
def init_db():
    """Initialize the database with proper schema"""
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        
        # Create fresh tables
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                theme TEXT DEFAULT 'light',
                notification_preference TEXT DEFAULT 'email'
            )
        """)
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS todos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                task TEXT NOT NULL,
                due_date TEXT NOT NULL,
                done BOOLEAN NOT NULL DEFAULT 0,
                category TEXT DEFAULT 'General',
                notes TEXT DEFAULT '',
                importance TEXT DEFAULT 'medium',
                progress INTEGER DEFAULT 0,  # Added progress column
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        conn.commit()  # Save changes to database
        logger.info("Database initialized successfully")  # Log success message
        return True  # Return True indicating success
    except sqlite3.Error as e:
        logger.error(f"Database initialization error: {e}")  # Log any database errors
        return False  # Return False on error
    finally:
        conn.close()  # Close connection

def migrate_db():
    """Add new columns to existing tables"""
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        
        # Check if category column exists
        cursor.execute("PRAGMA table_info(todos)")
        columns = [column[1] for column in cursor.fetchall()]
        
        # Add category column if it doesn't exist
        if 'category' not in columns:
            cursor.execute("ALTER TABLE todos ADD COLUMN category TEXT DEFAULT 'General'")
            conn.commit()
            logger.info("Added category column to todos table")
        
        # Check if theme and notification_preference columns exist
        cursor.execute("PRAGMA table_info(users)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'theme' not in columns:
            cursor.execute("ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'light'")
        if 'notification_preference' not in columns:
            cursor.execute("ALTER TABLE users ADD COLUMN notification_preference TEXT DEFAULT 'email'")
            
        # Check if notes column exists
        cursor.execute("PRAGMA table_info(todos)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'notes' not in columns:
            cursor.execute("ALTER TABLE todos ADD COLUMN notes TEXT DEFAULT ''")
            conn.commit()
            logger.info("Added notes column to todos table")
        
        # Check if importance column exists
        cursor.execute("PRAGMA table_info(todos)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'importance' not in columns:
            cursor.execute("ALTER TABLE todos ADD COLUMN importance TEXT DEFAULT 'medium'")
            conn.commit()
            logger.info("Added importance column to todos table")
        
        # Check if progress column exists
        cursor.execute("PRAGMA table_info(todos)")
        columns = [column[1] for column in cursor.fetchall()]
        
        if 'progress' not in columns:
            cursor.execute("ALTER TABLE todos ADD COLUMN progress INTEGER DEFAULT 0")
            conn.commit()
            logger.info("Added progress column to todos table")
            
        conn.commit()  # Save changes to database
        conn.close()  # Close connection
        return True  # Return True indicating success
    except sqlite3.Error as e:
        logger.error(f"Database migration error: {e}")  # Log any database errors
        return False  # Return False on error

# Initialize and migrate the database
init_db()
migrate_db()

# Update validate_user function
def validate_user(username, password):
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        cursor.execute("SELECT * FROM users WHERE username = ?", (username,))  # Query to get user by username
        user = cursor.fetchone()  # Fetch user data
        conn.close()  # Close connection
        
        if user and check_password_hash(user[2], password):  # Check if user exists and password matches
            return user  # Return user data
        return None  # Return None if user not found or password doesn't match
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")  # Log any database errors
        return None  # Return None on error


@app.route("/")
def home():
    stats = {
        'total_users': 0,
        'total_tasks': 0
    }
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        cursor.execute("SELECT COUNT(*) FROM users")  # Query to count total users
        stats['total_users'] = cursor.fetchone()[0]  # Get total users count
        cursor.execute("SELECT COUNT(*) FROM todos")  # Query to count total tasks
        stats['total_tasks'] = cursor.fetchone()[0]  # Get total tasks count
        conn.close()  # Close connection
    except sqlite3.Error as e:
        logger.error(f"Error fetching stats: {e}")  # Log any database errors
    
    return render_template("index.html", stats=stats)  # Render home page with stats


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")  # Get username from form
        password = request.form.get("password")  # Get password from form
        
        if not username or not password:  # Check if username and password are provided
            flash("Please provide both username and password", "error")  # Flash error message
            return redirect(url_for("login"))  # Redirect to login page
            
        user = validate_user(username, password)  # Validate user credentials
        if user:
            session['user_id'] = user[0]  # Set user ID in session
            session['username'] = user[1]  # Set username in session
            flash("Login successful!", "success")  # Flash success message
            return redirect(url_for("dashboard"))  # Redirect to dashboard
        
        flash("Invalid username or password!", "error")  # Flash error message
    return render_template("login.html")  # Render login page


@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form.get("username")  # Get username from form
        password = request.form.get("password")  # Get password from form
        
        if not username or not password:  # Check if username and password are provided
            flash("Username and password are required!", "error")  # Flash error message
            return redirect(url_for("signup"))  # Redirect to signup page
        
        # Try to add user to database
        if add_user_to_db(username, password):  # Add user to database
            flash("Account created successfully! Please log in.", "success")  # Flash success message
            return redirect(url_for("login"))  # Redirect to login page
        else:
            flash("Username already exists or an error occurred.", "error")  # Flash error message
            return redirect(url_for("signup"))  # Redirect to signup page

    return render_template("signup.html")  # Render signup page


def colour(days_left):
    """Determines the color based on days left until due date."""
    if days_left < 0:
        return "red"  # Overdue
    elif days_left == 0:
        return "yellow"  # Due today
    elif days_left == 1:
        return "yellow"  # Due tomorrow
    elif days_left <= 7:
        return "yellow"  # Due soon
    else:
        return "on-time"  # On time

@app.route("/dashboard", methods=["GET", "POST"])
@app.route("/dashboard/<show_completed>")
def dashboard(show_completed=None):
    if 'user_id' not in session:
        flash("Please login first!", "error")  # Flash error message
        return redirect(url_for("login"))  # Redirect to login page
        
    if request.method == "POST":
        task = request.form.get("todo_task")  # Get task from form
        due_date_str = request.form.get("due_date")  # Get due date from form
        category = request.form.get("category")  # Get category from form
        notes = request.form.get("notes", "")  # Get notes from form
        importance = request.form.get("importance", "medium")  # Get importance from form
        progress = int(request.form.get("progress", 0))  # Get progress from form
        
        if task and due_date_str and category:  # Check if task, due date, and category are provided
            try:
                # Parse only the date
                due_date = datetime.strptime(due_date_str, "%Y-%m-%d")  # Parse due date
                due_date_iso = due_date.date().isoformat()  # Convert to ISO format
                
                conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
                cursor = conn.cursor()  # Create database cursor
                cursor.execute(
                    "INSERT INTO todos (user_id, task, due_date, category, notes, importance, progress) VALUES (?, ?, ?, ?, ?, ?, ?)",  # SQL to insert new task
                    (session['user_id'], task, due_date_iso, category, notes, importance, progress)  # Values to insert
                )
                conn.commit()  # Save changes to database
                conn.close()  # Close connection
                flash("Task added successfully!", "success")  # Flash success message
            except ValueError:
                flash("Invalid date format.", "error")  # Flash error message
                return redirect(url_for("dashboard"))  # Redirect to dashboard
    
    conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
    cursor = conn.cursor()  # Create database cursor
    
    # Modify the query based on show_completed parameter
    if show_completed:
        cursor.execute("""
            SELECT id, task, due_date, category, notes, importance, progress, done 
            FROM todos 
            WHERE user_id = ? 
            ORDER BY done ASC, date(due_date) ASC
        """, (session['user_id'],))
    else:
        cursor.execute("""
            SELECT id, task, due_date, category, notes, importance, progress, done 
            FROM todos 
            WHERE user_id = ? AND done = 0 
            ORDER BY date(due_date) ASC
        """, (session['user_id'],))
    
    todos = cursor.fetchall()  # Fetch all tasks
    conn.close()  # Close connection
    
    # Format todos for template
    todo_list = []
    for todo in todos:
        due_date = datetime.fromisoformat(todo[2])  # Parse due date
        time_left = due_date.date() - date.today()  # Calculate time left
        days_left = time_left.days  # Get days left
        
        color = colour(days_left)  # Get color based on days left
        
        if days_left < 0:
            due_text = f"{abs(days_left)} days overdue"  # Overdue text
        elif days_left == 0:
            due_text = "Due today"  # Due today text
        elif days_left == 1:
            due_text = "Due tomorrow"  # Due tomorrow text
        else:
            due_text = f"{days_left} days left"  # Days left text
            
        todo_list.append({
            "id": todo[0],
            "task": todo[1],
            "due_date": due_date.strftime("%Y-%m-%d"),  # Format due date
            "category": todo[3],
            "notes": todo[4],
            "importance": todo[5],
            "progress": todo[6],  # Added progress
            "color": color,
            "due_text": due_text,
            "done": todo[7],  # Add the done status
        })
        
    return render_template("dashboard.html", 
                         todo_list=todo_list, 
                         show_completed=bool(show_completed))  # Render dashboard with todos

# Add route to update progress
@app.route("/update_progress/<int:task_id>", methods=["POST"])
def update_progress(task_id):
    if 'user_id' not in session:
        return "Unauthorized", 401  # Return unauthorized status
    
    new_progress = request.form.get("progress")  # Get new progress from form
    if new_progress is None:
        return "Bad Request", 400  # Return bad request status
    try:
        new_progress = int(new_progress)  # Convert progress to integer
        if not 0 <= new_progress <= 100:
            raise ValueError
    except ValueError:
        return "Invalid progress value", 400  # Return invalid progress value status
    
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        cursor.execute("""
            UPDATE todos 
            SET progress = ? 
            WHERE id = ? AND user_id = ?
        """, (new_progress, task_id, session['user_id']))  # Update progress
        conn.commit()  # Save changes to database
        conn.close()  # Close connection
        return "Success", 200  # Return success status
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")  # Log any database errors
        return "Internal Server Error", 500  # Return internal server error status

@app.route("/complete/task/<int:task_id>", methods=["POST"])
def complete_task(task_id):
    if 'user_id' not in session:
        return "Unauthorized", 401  # Return unauthorized status
    
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        cursor.execute("""
            UPDATE todos 
            SET done = 1 
            WHERE id = ? AND user_id = ?
        """, (task_id, session['user_id']))  # Mark task as done
        conn.commit()  # Save changes to database
        conn.close()  # Close connection
        return "Success", 200  # Return success status
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")  # Log any database errors
        return "Internal Server Error", 500  # Return internal server error status

@app.route("/toggle/task/<int:task_id>", methods=["POST"])
def toggle_task(task_id):
    if 'user_id' not in session:
        return "Unauthorized", 401  # Return unauthorized status
    
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        # First get current state
        cursor.execute("SELECT done FROM todos WHERE id = ? AND user_id = ?", (task_id, session['user_id']))  # Get current state
        current_state = cursor.fetchone()  # Fetch current state
        
        if current_state is None:
            return "Task not found", 404  # Return task not found status
            
        # Toggle the state
        new_state = 0 if current_state[0] else 1  # Toggle done state
        cursor.execute("""
            UPDATE todos 
            SET done = ? 
            WHERE id = ? AND user_id = ?
        """, (new_state, task_id, session['user_id']))  # Update done state
        conn.commit()  # Save changes to database
        conn.close()  # Close connection
        return "Success", 200  # Return success status
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")  # Log any database errors
        return "Internal Server Error", 500  # Return internal server error status

@app.route("/delete/dashboard/<int:task_id>")
def delete_task(task_id):
    conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
    cursor = conn.cursor()  # Create database cursor
    cursor.execute("DELETE FROM todos WHERE id = ? AND user_id = ?", (task_id, session['user_id']))  # Delete task
    conn.commit()  # Save changes to database
    conn.close()  # Close connection
    return redirect(url_for("dashboard"))  # Redirect to dashboard


@app.route("/logout")
def logout():
    session.clear()  # Clear session
    flash("You have been logged out!", "success")  # Flash success message
    return redirect(url_for("login"))  # Redirect to login page


@app.route("/calendar")
def calendar_view():
    if 'user_id' not in session:
        flash("Please login first!", "error")  # Flash error message
        return redirect(url_for("login"))  # Redirect to login page

    # Get current year and month from query parameters or use current date
    year = int(request.args.get('year', datetime.now().year))  # Get year from query parameters
    month = int(request.args.get('month', datetime.now().month))  # Get month from query parameters

    # Calculate previous and next month/year
    first_day = date(year, month, 1)  # Get first day of the month
    prev_month = (first_day - timedelta(days=1)).replace(day=1)  # Calculate previous month
    next_month = (first_day + timedelta(days=32)).replace(day=1)  # Calculate next month

    # Get calendar data
    cal = calendar.monthcalendar(year, month)  # Get month calendar
    month_name = calendar.month_name[month]  # Get month name

    # Get tasks for the current month - update query to include notes
    conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
    cursor = conn.cursor()  # Create database cursor
    cursor.execute("""
        SELECT task, due_date, category, notes 
        FROM todos 
        WHERE user_id = ? 
        AND strftime('%Y-%m', due_date) = strftime('%Y-%m', ?)
        ORDER BY date(due_date) ASC
    """, (session['user_id'], f"{year}-{month:02d}-01"))  # Get tasks for the current month
    tasks = cursor.fetchall()  # Fetch tasks
    conn.close()  # Close connection

    # Organize tasks by date - update task dictionary to include notes
    task_dict = {}
    for task in tasks:
        task_date = datetime.strptime(task[1], "%Y-%m-%d").date()  # Parse task date
        if task_date not in task_dict:
            task_dict[task_date] = []
        days_left = (task_date - date.today()).days  # Calculate days left
        task_color = colour(days_left)  # Get task color
        task_dict[task_date].append({
            "task": task[0],
            "due_date": task[1],
            "category": task[2],
            "notes": task[3],
            "color": task_color
        })

    # Build calendar data
    calendar_data = []
    for week in cal:
        week_data = []
        for day in week:
            if day == 0:
                week_data.append({"day": "", "tasks": []})  # Empty day
            else:
                current_date = date(year, month, day)  # Get current date
                week_data.append({
                    "day": day,
                    "today": current_date == date.today(),  # Check if today
                    "tasks": task_dict.get(current_date, [])  # Get tasks for the day
                })
        calendar_data.append(week_data)

    return render_template("calendar.html",
                         calendar_data=calendar_data,
                         month_name=month_name,
                         year=year,
                         prev_month=prev_month.month,
                         prev_year=prev_month.year,
                         next_month=next_month.month,
                         next_year=next_month.year,
                         active_page='calendar')  # Render calendar view


@app.route("/settings", methods=["GET", "POST"])
def settings():
    if 'user_id' not in session:
        flash("Please login first!", "error")  # Flash error message
        return redirect(url_for("login"))  # Redirect to login page
    
    if request.method == "POST":
        theme = request.form.get("theme", "light")  # Get theme from form
        notification_preference = request.form.get("notification_preference", "email")  # Get notification preference from form
        new_username = request.form.get("new_username")  # Get new username from form
        current_password = request.form.get("current_password")  # Get current password from form
        new_password = request.form.get("new_password")  # Get new password from form
        
        try:
            conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
            cursor = conn.cursor()  # Create database cursor
            
            # First verify current password if attempting password change
            if current_password and new_password:
                cursor.execute("SELECT password FROM users WHERE id = ?", (session['user_id'],))  # Get stored password
                stored_password = cursor.fetchone()[0]  # Fetch stored password
                if not check_password_hash(stored_password, current_password):  # Check if current password matches
                    flash("Current password is incorrect!", "error")  # Flash error message
                    return redirect(url_for("settings"))  # Redirect to settings page
                
                # Update password
                hashed_password = generate_password_hash(new_password)  # Hash new password
                cursor.execute("""
                    UPDATE users 
                    SET password = ?
                    WHERE id = ?
                """, (hashed_password, session['user_id']))  # Update password
                flash("Password updated successfully!", "success")  # Flash success message
            
            # Update username if provided
            if new_username and new_username != session['username']:
                cursor.execute("UPDATE users SET username = ? WHERE id = ?", 
                             (new_username, session['user_id']))  # Update username
                session['username'] = new_username  # Update session username
                flash("Username updated successfully!", "success")  # Flash success message
            
            # Update theme and notifications
            cursor.execute("""
                UPDATE users 
                SET theme = ?, notification_preference = ?
                WHERE id = ?
            """, (theme, notification_preference, session['user_id']))  # Update theme and notification preference
            
            conn.commit()  # Save changes to database
            
            # Fetch updated settings
            cursor.execute("""
                SELECT theme, notification_preference, username 
                FROM users 
                WHERE id = ?
            """, (session['user_id'],))  # Get updated settings
            user_settings = cursor.fetchone()  # Fetch updated settings
            conn.close()  # Close connection
            
            if not user_settings:
                flash("Error loading settings", "error")  # Flash error message
                return redirect(url_for("dashboard"))  # Redirect to dashboard
                
            settings_dict = {
                'theme': user_settings[0],
                'notification_preference': user_settings[1],
                'username': user_settings[2]
            }
            
            return render_template("settings.html", 
                                 settings=settings_dict,
                                 active_page='settings')  # Render settings page
                                 
        except sqlite3.Error as e:
            logger.error(f"Database error: {e}")  # Log any database errors
            flash("Error updating settings", "error")  # Flash error message
            return redirect(url_for("settings"))  # Redirect to settings page
    
    # GET request - display current settings
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        cursor.execute("""
            SELECT theme, notification_preference, username 
            FROM users 
            WHERE id = ?
        """, (session['user_id'],))  # Get current settings
        user_settings = cursor.fetchone()  # Fetch current settings
        conn.close()  # Close connection
        
        if not user_settings:
            flash("Error loading settings", "error")  # Flash error message
            return redirect(url_for("dashboard"))  # Redirect to dashboard
            
        settings_dict = {
            'theme': user_settings[0],
            'notification_preference': user_settings[1],
            'username': user_settings[2]
        }
        
        return render_template("settings.html", 
                             settings=settings_dict,
                             active_page='settings')  # Render settings page
                             
    except sqlite3.Error as e:
        logger.error(f"Database error: {e}")  # Log any database errors
        flash("Error loading settings", "error")  # Flash error message
        return redirect(url_for("dashboard"))  # Redirect to dashboard

def reset_database():
    """Reset the database by dropping and recreating tables"""
    try:
        conn = sqlite3.connect(DB_PATH)  # Connect to SQLite database
        cursor = conn.cursor()  # Create database cursor
        
        # Drop existing tables
        cursor.execute("DROP TABLE IF EXISTS todos")  # Drop todos table
        cursor.execute("DROP TABLE IF EXISTS users")  # Drop users table
        
        # Recreate tables
        cursor.execute("""
            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                theme TEXT DEFAULT 'light',
                notification_preference TEXT DEFAULT 'email'
            )
        """)
        
        cursor.execute("""
            CREATE TABLE todos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                task TEXT NOT NULL,
                due_date TEXT NOT NULL,
                done BOOLEAN NOT NULL DEFAULT 0,
                category TEXT DEFAULT 'General',
                notes TEXT DEFAULT '',
                importance TEXT DEFAULT 'medium',
                progress INTEGER DEFAULT 0,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        conn.commit()  # Save changes to database
        conn.close()  # Close connection
        return True  # Return True indicating success
    except sqlite3.Error as e:
        logger.error(f"Database reset error: {e}")  # Log any database errors
        return False  # Return False on error

@app.route("/reset", methods=["GET"])
def reset():
    if reset_database():
        session.clear()  # Clear current session
        flash("Database has been reset. Please sign up for a new account.", "success")  # Flash success message
    else:
        flash("Failed to reset database.", "error")  # Flash error message
    return redirect(url_for("login"))  # Redirect to login page

if __name__ == "__main__":
    app.run(debug=True)  # Run Flask application in debug mode